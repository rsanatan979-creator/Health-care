# MediQueue - Quick Start Guide

## 🚀 Get Started in 2 Minutes

### 1. Install Dependencies
```bash
pnpm install
```
(or `npm install` if you prefer npm)

### 2. Start the App
```bash
pnpm dev
```

### 3. Open in Browser
- **Frontend**: http://localhost:5173
- **API**: http://localhost:3000/api

That's it! You now have the full application running.

## 📱 What to Try First

1. **View the Dashboard**
   - See real-time queue with 4 sample patients
   - Check emergency alerts and doctor availability
   - Click "Refresh" to see real-time updates

2. **Add a New Patient**
   - Click "Add Patient" button
   - Fill in sample data: Jane Doe, Fever, Severe
   - Watch it appear in the dashboard instantly!

3. **Check Doctor Schedule**
   - Click "Schedule" to see doctor availability
   - View appointment slots and AI optimization tips

4. **View Analytics**
   - Click "Analytics" to see detailed charts
   - Monitor doctor utilization, symptom distribution, severity levels

## 🧠 AI Features to Explore

- **Smart Wait Time Prediction**: Estimates based on queue length, severity, and doctor availability
- **Emergency Prioritization**: Emergency cases jump to the front of the queue
- **Doctor Optimization**: AI recommends best doctor for each patient
- **Real-time Updates**: Queue refreshes automatically every 5 seconds

## 📊 API Endpoints

Try these in your browser or API client:

```
# Get queue status
http://localhost:3000/api/queue

# Get all patients
http://localhost:3000/api/patients

# Get all doctors
http://localhost:3000/api/doctors

# Get analytics
http://localhost:3000/api/queue/analytics

# Predict wait time for patient P001
http://localhost:3000/api/predict/wait-time/P001

# Optimize queue order
http://localhost:3000/api/predict/optimize-queue
```

## 🎨 How to Customize

### Change Colors
Edit `client/global.css` - look for CSS variables in `:root` section

### Add More Doctors
Edit `server/db.ts` - modify the `doctors` array

### Change Sample Patients
Edit `server/db.ts` - modify the `patients` array

### Add Custom Functionality
Create new pages in `client/pages/` and add routes in `client/App.tsx`

## 🚢 Deployment

### For Hackathon Demo
Simply use the local dev server - it's fast and works great for presentations!

### For Production
See `DEPLOYMENT_AND_DEMO_GUIDE.md` for:
- Netlify deployment
- Vercel deployment
- Self-hosted options
- Docker setup

## 📚 Documentation

- **Full API Docs**: See `DEPLOYMENT_AND_DEMO_GUIDE.md`
- **Database Schema**: See `DATABASE_SCHEMA.md`
- **Architecture**: See `AGENTS.md`
- **Demo Script**: See `DEPLOYMENT_AND_DEMO_GUIDE.md#demo-walkthrough`

## 🐛 Troubleshooting

**App won't start?**
```bash
# Clear everything and reinstall
rm -rf node_modules pnpm-lock.yaml
pnpm install
pnpm dev
```

**Port 5173 already in use?**
```bash
PORT=5174 pnpm dev
```

**API not responding?**
- Make sure you see "Server running on port 3000" in terminal
- Check browser console for CORS errors

**Data not showing?**
- Click "Refresh" button on dashboard
- Check network tab in browser DevTools
- Ensure backend is running

## 🎯 Next Steps

1. **Demo the App**: Run the dashboard and try adding a patient
2. **Understand the Code**: Browse through the pages and components
3. **Customize**: Add your own features, colors, and data
4. **Deploy**: Follow deployment guide for production
5. **Pitch**: Use the demo walkthrough script for presentations

## 💡 Pro Tips

- **Real-time Demo**: Data refreshes every 5 seconds - great for live presentations
- **Add Multiple Patients**: Click "Add Patient" multiple times to populate queue
- **Show Emergency Priority**: Mark a patient as emergency to see it jump the queue
- **Analytics Insight**: Patient data affects the charts - add patients of different severity levels
- **API Testing**: Use curl or Postman to test endpoints and show the API in action

## 📞 Support

- **Questions?**: Check documentation files
- **Found a bug?**: Check your code for typos
- **Want to add features?**: Edit the relevant files in `client/pages/` or `server/routes/`

---

**Ready to impress with a demo? Start with step 1-3 above, and you're good to go!** 🎉
