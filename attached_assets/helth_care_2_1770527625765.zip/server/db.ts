// In-memory database for the demo
// In production, this would use SQLite or another database

export interface Patient {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  dateOfBirth: string;
  gender: string;
  symptom: string;
  severity: "mild" | "moderate" | "severe";
  isEmergency: boolean;
  notes: string;
  arrivalTime: string;
  estimatedWait: number;
  doctorAssigned?: string;
  status: "waiting" | "in-progress" | "completed";
}

export interface Doctor {
  id: string;
  name: string;
  specialization: string;
  status: "available" | "busy" | "break";
  currentPatients: number;
  maxCapacity: number;
}

export interface Appointment {
  id: string;
  patientId: string;
  doctorId: string;
  scheduledTime: string;
  duration: number;
  confirmed: boolean;
  notes?: string;
}

export interface Prediction {
  patientId: string;
  estimatedWaitTime: number;
  confidence: number;
  reason: string;
  recommendation?: string;
}

// In-memory storage
let patients: Patient[] = [
  {
    id: "P001",
    firstName: "John",
    lastName: "Smith",
    email: "john@example.com",
    phone: "+1-555-0101",
    dateOfBirth: "1985-03-15",
    gender: "male",
    symptom: "Chest Pain",
    severity: "severe",
    isEmergency: false,
    notes: "Intermittent chest pain for 2 hours",
    arrivalTime: "09:15 AM",
    estimatedWait: 8,
    doctorAssigned: "Dr. Sarah Williams",
    status: "in-progress",
  },
  {
    id: "P002",
    firstName: "Emma",
    lastName: "Johnson",
    email: "emma@example.com",
    phone: "+1-555-0102",
    dateOfBirth: "1992-07-22",
    gender: "female",
    symptom: "Severe Allergic Reaction",
    severity: "severe",
    isEmergency: true,
    notes: "Breathing difficulty, visible swelling",
    arrivalTime: "09:30 AM",
    estimatedWait: 12,
    doctorAssigned: "Dr. Michael Chen",
    status: "in-progress",
  },
  {
    id: "P003",
    firstName: "Robert",
    lastName: "Brown",
    email: "robert@example.com",
    phone: "+1-555-0103",
    dateOfBirth: "1978-11-08",
    gender: "male",
    symptom: "Broken Arm",
    severity: "severe",
    isEmergency: false,
    notes: "Fall from height, left arm broken",
    arrivalTime: "09:45 AM",
    estimatedWait: 22,
    status: "waiting",
  },
];

let doctors: Doctor[] = [
  {
    id: "D001",
    name: "Dr. Sarah Williams",
    specialization: "Emergency Medicine",
    status: "busy",
    currentPatients: 2,
    maxCapacity: 5,
  },
  {
    id: "D002",
    name: "Dr. Michael Chen",
    specialization: "Cardiology",
    status: "busy",
    currentPatients: 1,
    maxCapacity: 4,
  },
  {
    id: "D003",
    name: "Dr. Jennifer Lee",
    specialization: "Orthopedics",
    status: "available",
    currentPatients: 0,
    maxCapacity: 5,
  },
  {
    id: "D004",
    name: "Dr. Robert Martinez",
    specialization: "General Medicine",
    status: "break",
    currentPatients: 0,
    maxCapacity: 6,
  },
];

let appointments: Appointment[] = [];

// Patient operations
export const db = {
  // Patient operations
  getPatients: (): Patient[] => patients,

  getPatientById: (id: string): Patient | undefined =>
    patients.find((p) => p.id === id),

  addPatient: (patientData: Omit<Patient, "id" | "arrivalTime" | "estimatedWait" | "status">): Patient => {
    const newPatient: Patient = {
      ...patientData,
      id: `P${String(patients.length + 1).padStart(3, "0")}`,
      arrivalTime: new Date().toLocaleTimeString("en-US", {
        hour: "2-digit",
        minute: "2-digit",
      }),
      estimatedWait: Math.floor(Math.random() * 30) + 5,
      status: "waiting",
    };
    patients.push(newPatient);
    return newPatient;
  },

  updatePatient: (id: string, updates: Partial<Patient>): Patient | undefined => {
    const index = patients.findIndex((p) => p.id === id);
    if (index !== -1) {
      patients[index] = { ...patients[index], ...updates };
      return patients[index];
    }
    return undefined;
  },

  // Doctor operations
  getDoctors: (): Doctor[] => doctors,

  getDoctorById: (id: string): Doctor | undefined =>
    doctors.find((d) => d.id === id),

  updateDoctor: (id: string, updates: Partial<Doctor>): Doctor | undefined => {
    const index = doctors.findIndex((d) => d.id === id);
    if (index !== -1) {
      doctors[index] = { ...doctors[index], ...updates };
      return doctors[index];
    }
    return undefined;
  },

  getAvailableDoctors: (): Doctor[] =>
    doctors.filter((d) => d.status === "available" && d.currentPatients < d.maxCapacity),

  // Appointment operations
  getAppointments: (): Appointment[] => appointments,

  addAppointment: (
    patientId: string,
    doctorId: string,
    scheduledTime: string
  ): Appointment | null => {
    const doctor = db.getDoctorById(doctorId);
    if (!doctor || doctor.currentPatients >= doctor.maxCapacity) {
      return null;
    }

    const appointment: Appointment = {
      id: `A${String(appointments.length + 1).padStart(3, "0")}`,
      patientId,
      doctorId,
      scheduledTime,
      duration: 30,
      confirmed: false,
    };

    appointments.push(appointment);
    return appointment;
  },

  // Queue operations
  getQueueStats: () => {
    const waitingPatients = patients.filter((p) => p.status === "waiting");
    const avgWait =
      waitingPatients.length > 0
        ? waitingPatients.reduce((sum, p) => sum + p.estimatedWait, 0) /
          waitingPatients.length
        : 0;

    return {
      totalPatients: patients.length,
      waitingPatients: waitingPatients.length,
      avgWaitTime: Math.round(avgWait),
      emergencyCount: patients.filter((p) => p.isEmergency).length,
      completedToday: patients.filter((p) => p.status === "completed").length,
    };
  },

  // Simulation - update wait times
  simulateQueueUpdate: () => {
    patients.forEach((patient) => {
      if (patient.estimatedWait > 0) {
        patient.estimatedWait = Math.max(0, patient.estimatedWait - 1);
      }
    });
  },
};
