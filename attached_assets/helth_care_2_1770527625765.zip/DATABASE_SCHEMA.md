# MediQueue - Database Schema & Setup

## Overview

MediQueue uses an in-memory database for demo purposes, but is designed to be easily adaptable to SQLite or other databases. The current implementation uses TypeScript objects stored in memory (`server/db.ts`).

For production deployment, you can migrate to SQLite following the schema below.

## Database Tables

### 1. PATIENTS Table
```sql
CREATE TABLE patients (
  id VARCHAR(10) PRIMARY KEY,
  first_name VARCHAR(100) NOT NULL,
  last_name VARCHAR(100) NOT NULL,
  email VARCHAR(100) NOT NULL,
  phone VARCHAR(20) NOT NULL,
  date_of_birth DATE NOT NULL,
  gender VARCHAR(20),
  symptom VARCHAR(255) NOT NULL,
  severity VARCHAR(20) DEFAULT 'moderate',
  is_emergency BOOLEAN DEFAULT false,
  notes TEXT,
  arrival_time TIME NOT NULL,
  estimated_wait INTEGER DEFAULT 0,
  doctor_assigned VARCHAR(100),
  status VARCHAR(20) DEFAULT 'waiting',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_patients_status ON patients(status);
CREATE INDEX idx_patients_arrival_time ON patients(arrival_time);
CREATE INDEX idx_patients_is_emergency ON patients(is_emergency);
```

### 2. DOCTORS Table
```sql
CREATE TABLE doctors (
  id VARCHAR(10) PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  specialization VARCHAR(100) NOT NULL,
  status VARCHAR(20) DEFAULT 'available',
  current_patients INTEGER DEFAULT 0,
  max_capacity INTEGER DEFAULT 5,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_doctors_status ON doctors(status);
```

### 3. APPOINTMENTS Table
```sql
CREATE TABLE appointments (
  id VARCHAR(10) PRIMARY KEY,
  patient_id VARCHAR(10) NOT NULL,
  doctor_id VARCHAR(10) NOT NULL,
  scheduled_time TIMESTAMP NOT NULL,
  duration INTEGER DEFAULT 30,
  confirmed BOOLEAN DEFAULT false,
  notes TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (patient_id) REFERENCES patients(id),
  FOREIGN KEY (doctor_id) REFERENCES doctors(id)
);

CREATE INDEX idx_appointments_patient_id ON appointments(patient_id);
CREATE INDEX idx_appointments_doctor_id ON appointments(doctor_id);
CREATE INDEX idx_appointments_scheduled_time ON appointments(scheduled_time);
```

### 4. QUEUE_HISTORY Table (for analytics)
```sql
CREATE TABLE queue_history (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  patient_id VARCHAR(10) NOT NULL,
  event_type VARCHAR(50) NOT NULL,
  event_timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  doctor_id VARCHAR(10),
  details JSON,
  FOREIGN KEY (patient_id) REFERENCES patients(id),
  FOREIGN KEY (doctor_id) REFERENCES doctors(id)
);

CREATE INDEX idx_queue_history_patient_id ON queue_history(patient_id);
CREATE INDEX idx_queue_history_event_type ON queue_history(event_type);
CREATE INDEX idx_queue_history_event_timestamp ON queue_history(event_timestamp);
```

### 5. PREDICTIONS_LOG Table (for AI audit trail)
```sql
CREATE TABLE predictions_log (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  patient_id VARCHAR(10) NOT NULL,
  predicted_wait_time INTEGER NOT NULL,
  actual_wait_time INTEGER,
  confidence_score FLOAT,
  prediction_timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  doctor_assigned VARCHAR(100),
  recommendation TEXT,
  FOREIGN KEY (patient_id) REFERENCES patients(id)
);

CREATE INDEX idx_predictions_log_patient_id ON predictions_log(patient_id);
CREATE INDEX idx_predictions_log_prediction_timestamp ON predictions_log(prediction_timestamp);
```

## Sample Data

### Initial Doctors
```sql
INSERT INTO doctors (id, name, specialization, status, current_patients, max_capacity) VALUES
('D001', 'Dr. Sarah Williams', 'Emergency Medicine', 'busy', 2, 5),
('D002', 'Dr. Michael Chen', 'Cardiology', 'busy', 1, 4),
('D003', 'Dr. Jennifer Lee', 'Orthopedics', 'available', 0, 5),
('D004', 'Dr. Robert Martinez', 'General Medicine', 'break', 0, 6);
```

### Initial Patients (for demo)
```sql
INSERT INTO patients (id, first_name, last_name, email, phone, date_of_birth, gender, symptom, severity, is_emergency, arrival_time, estimated_wait, doctor_assigned, status) VALUES
('P001', 'John', 'Smith', 'john@example.com', '+1-555-0101', '1985-03-15', 'male', 'Chest Pain', 'severe', false, '09:15', 8, 'Dr. Sarah Williams', 'in-progress'),
('P002', 'Emma', 'Johnson', 'emma@example.com', '+1-555-0102', '1992-07-22', 'female', 'Severe Allergic Reaction', 'severe', true, '09:30', 12, 'Dr. Michael Chen', 'in-progress'),
('P003', 'Robert', 'Brown', 'robert@example.com', '+1-555-0103', '1978-11-08', 'male', 'Broken Arm', 'severe', false, '09:45', 22, NULL, 'waiting');
```

## Migration Guide (In-Memory to SQLite)

### Step 1: Install SQLite Package
```bash
npm install better-sqlite3
# or
npm install sqlite3
```

### Step 2: Create Database Initialization Script
```typescript
// server/db-init.ts
import Database from 'better-sqlite3';
import fs from 'fs';
import path from 'path';

const dbPath = path.join(process.cwd(), 'data', 'mediqueue.db');

export function initializeDatabase() {
  const db = new Database(dbPath);
  
  // Create tables if they don't exist
  const schema = fs.readFileSync(path.join(__dirname, 'schema.sql'), 'utf-8');
  db.exec(schema);
  
  // Insert initial data
  const seed = fs.readFileSync(path.join(__dirname, 'seed.sql'), 'utf-8');
  db.exec(seed);
  
  return db;
}
```

### Step 3: Update db.ts to Use SQLite
Replace the in-memory implementation with SQLite queries:

```typescript
import Database from 'better-sqlite3';

const db = new Database('data/mediqueue.db');

export const dbOperations = {
  getPatients: () => db.prepare('SELECT * FROM patients').all(),
  addPatient: (patientData) => {
    const stmt = db.prepare(`
      INSERT INTO patients (...) VALUES (...)
    `);
    return stmt.run(patientData);
  },
  // ... other operations
};
```

## Data Retention Policies

- **Active Patients**: Kept until status = 'completed'
- **Completed Patients**: Kept for 30 days
- **Queue History**: Kept for 90 days for analytics
- **Predictions Log**: Kept for 180 days for model improvement

## API Endpoints for Data Management

### Get Queue Stats
```
GET /api/queue
```

### Get Queue Analytics
```
GET /api/queue/analytics
```

### Add Patient
```
POST /api/patients
Body: {
  firstName: string,
  lastName: string,
  email: string,
  phone: string,
  dateOfBirth: string,
  gender: string,
  symptom: string,
  severity: 'mild' | 'moderate' | 'severe',
  isEmergency: boolean,
  notes: string
}
```

### Get All Patients
```
GET /api/patients
```

### Get All Doctors
```
GET /api/doctors
```

## Performance Optimization

### Indexes Created
- `patients.status` - For fast filtering of active patients
- `patients.arrival_time` - For sorting queue by arrival
- `patients.is_emergency` - For emergency triage
- `doctors.status` - For finding available doctors
- `appointments.scheduled_time` - For scheduling queries
- `queue_history.event_timestamp` - For analytics

### Query Optimization Tips
1. Use indexes for WHERE clauses on `status`, `arrival_time`, `is_emergency`
2. Use pagination for large result sets (add LIMIT/OFFSET)
3. Cache frequently accessed doctor availability data
4. Use prepared statements to prevent SQL injection

## Backup Strategy

For production deployment:

1. **Daily Backups**: Automated backup of database file
   ```bash
   # Example: backup.sh
   cp data/mediqueue.db backups/mediqueue-$(date +%Y%m%d).db
   ```

2. **Cloud Backup**: Use cloud storage (AWS S3, Google Cloud Storage)
   ```bash
   aws s3 cp data/mediqueue.db s3://mediqueue-backups/
   ```

3. **Transaction Logging**: Enable SQLite WAL mode for reliability
   ```sql
   PRAGMA journal_mode=WAL;
   ```

## Testing Data

See `server/db.ts` for pre-configured test data that's loaded on application startup.

## Future Enhancements

1. **Analytics Database**: Separate read-only database for reporting
2. **Real-time Sync**: Use database triggers for real-time notifications
3. **Data Encryption**: Encrypt sensitive patient data at rest
4. **Audit Logging**: Track all data modifications for compliance
